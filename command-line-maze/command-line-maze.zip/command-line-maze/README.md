# Command Line Maze
Welcome to the maze!

Start from the only 'entrance', and find the exit by yourself.

The clue might be helpful.

The sky is getting dark, you see a shadow in the maze...

Take your time and good luck!
